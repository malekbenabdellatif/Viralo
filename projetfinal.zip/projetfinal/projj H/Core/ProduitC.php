<?php 
if (!(class_exists('config'))){
include "../../config.php";
}
Class ProduitC {
	function ajouterProduit($cat){
		
		$sql="INSERT INTO `produit` (`nom_produit`, `reference`, `quantite`, `nomc`, `prix`, `img`, `description`) VALUES (:nom_produit,:reference, :quantite,:nomc,:prix,:img,:description)";
	$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
	
        $nom_produit=$cat->getNom_produit();
        $reference=$cat->getReference();
        $quantite=$cat->getQuantite();  
        $nomc=$cat->getNomc();
        $prix=$cat->getPrix();
        $img=$cat->getImg();
        $description=$cat->getDescription();

       
		$req->bindValue(':nom_produit',$nom_produit);
		$req->bindValue(':reference',$reference);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':nomc',$nomc);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':img',$img);
		$req->bindValue(':description',$description);


		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
function AffichProduit()
{
$sq2 = "select * from produit";
	$db = config::getConnexion();
	try{
		$liste = $db->query($sq2); 
return $liste;
	}
	catch(Exception $ee){
 echo 'Erreur: '.$ee->getMessage();
	}
}


function supprimerProduit($id_produit)
{
		$sql="DELETE FROM produit where id_produit= :id_produit";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id_produit',$id_produit);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
}

	function ModifierProduit($cat,$id_produit)
	{
		$sql="UPDATE produit SET nom_produit=:nom_produit,reference=reference,quantite=quantite,nomc=nomc,img=:img,description=description WHERE id_produit=:id_produit";
		
		$db = config::getConnexion();

		try{		
        $req=$db->prepare($sql);
        $nom_produit=$cat->getNom_produit();
        $reference=$cat->getReference();
        $quantite=$cat->getQuantite();  
        $nomc=$cat->getNomc();
        $prix=$cat->getPrix();
        $img=$cat->getImg();
        $description=$cat->getDescription();

        
		$datas = array(':nom_produit'=>$nom_produit, ':reference'=>$reference, ':quantite'=>$quantite, ':nomc=>$nomc', ':prix'=>$prix, ':img'=>$img, ':description'=>$description);

		$req->bindValue(':nom_produit',$nom_produit);
		$req->bindValue(':reference',$reference);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':nomc',$nomc);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':img',$img);
		$req->bindValue(':description',$description);

	

		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
		function recupererProduit($id_produit){
		$sql="SELECT * from produit where id_produit=$id_produit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
		function rechercherListeProduit($nom_produit){
		$sql="SELECT * from produit where nom_produit=$nom_produit";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
		function GetProduit($id){
$sql  = "select * from produit where id_produit =$id";
	$db = config::getConnexion();
	try{
		$produit = $db->query($sql); 
return $produit ;
	}
	catch(Exception $e){
 echo 'Erreur: '.$e->getMessage();
	}
}
}

?>