<?php 
if (!(class_exists('config'))){
include "../../config.php";
}

}
?>