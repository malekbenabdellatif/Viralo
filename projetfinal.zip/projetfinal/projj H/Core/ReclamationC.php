<?PHP
//include "../config.php";
class ReclamationC {
function AfficherReclamation($reclamation){
		
		echo "mail : ".$reclamation->getMail()."<br>";
		echo "sujet : ".$reclamation->getSujet()."<br>";
		echo "textreclamation : ".$reclamation->getTextreclamation()."<br>";
	
	}
	
	/*function calculerSalaire($event){
		echo $event->getDescription() * $event->getDescription();
	}*/
	function AjouterReclamation($reclamation){
		$sql="insert into reclamation (mail,sujet,textreclamation) values (:mail,:sujet,:textreclamation)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
	
        
        $mail=$reclamation->getMail();
        $sujet=$reclamation->getSujet();
        $textreclamation=$reclamation->getTextreclamation();

		
		$req->bindValue(':mail',$mail);
		$req->bindValue(':sujet',$sujet);
        $req->bindValue(':textreclamation',$textreclamation);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function AfficherReclamations(){
		$sql="SElECT * From reclamation";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	
	
	
}

?>