<?PHP
include "../../config.php";
class CategorieC {
function afficherCategorie ($cat){
		echo "Nom categorie: ".$cat->getNom()."<br>";
		echo "image: ".$cat->getImg()."<br>";
	
	}
	/*function calculerSalaire($event){
		echo $event->getDescription() * $event->getDescription();
	}*/
	function ajouterCategorie($cat){
		$sql="insert into categorie (nom,img) values (:nom,:img)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
	
        $nom=$cat->getNom();
        $img=$cat->getImg();
       
		$req->bindValue(':nom',$nom);
		$req->bindValue(':img',$img);

		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherCategories(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From categorie";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerCategorie($nom)
	{
		$sql="DELETE FROM categorie where nom= :nom";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':nom',$nom);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierCategorie($cat,$nom){
		$sql="UPDATE categorie SET nom=:nom,img=:img WHERE nom=:nom";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
        $nom=$cat->getNom();
        $img=$cat->getImg();
        
		$datas = array(':nom'=>$nom,':img'=>$img);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':img',$img);
	

		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererCategorie($nom){
		$sql="SELECT * from categorie where nom=$nom";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeCategorie($nom){
		$sql="SELECT * from categorie where nom=$nom";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>