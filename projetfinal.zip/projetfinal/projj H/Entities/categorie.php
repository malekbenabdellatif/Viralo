<?PHP
class Categorie{
	private $nom;
	private $img;
	function __construct($nom,$img)
	{
		$this->nom=$nom;
		$this->img=$img;
	}
	function getNom()
	{
		return $this->nom;
	}
	
	function getImg()
	{
		return $this->img;
	}
	

	function setImg($img)
	{
		 $this->img=$img;
	}

	function setNom($nom)
	{
		 $this->nom=$nom;
	}
	

}
?>