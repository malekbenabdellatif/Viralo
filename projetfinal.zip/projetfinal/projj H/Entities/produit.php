<?PHP
class Produit{
	private $id_produit;
	private $nom_produit;
	private $reference;
	private $quantite;
	private $nomc;
	private $prix;
	private $img;
	private $description;
	function __construct($nom_produit,$reference,$quantite,$nomc,$prix,$img,$description)
	{
		$this->nom_produit=$nom_produit;
		$this->reference=$reference;
		$this->quantite=$quantite;
		$this->nomc=$nomc;
		$this->prix=$prix;
		$this->img=$img;
		$this->description=$description;
	}

	function getId_produit()
	{
		return $this->id_produit;
	}
	function getNom_produit()
	{
		return $this->nom_produit;
	}
	function getReference()
	{
		return $this->reference;
	}
	function getQuantite()
	{
		return $this->quantite;
	}
	function getNomc()
	{
		return $this->nomc;
	}
	function getPrix()
	{
		return $this->prix;
	}
	function getImg()
	{
		return $this->img;
	}
	function getDescription()
	{
		return $this->description;
	}
	function setNom_produit($nom_produit)
	{
		 $this->nom_produit=$nom_produit;
	}
	function setReference($reference)
	{
		 $this->reference=$reference;
	}
	function setQuantite($quantite)
	{
		 $this->quantite=$quantite;
	}
	function setNomc($nomc)
	{
		 $this->nomc=$nomc;
	}
	function setPrix($prix)
	{
		 $this->prix=$prix;
	}
	function setImg($img)
	{
		 $this->img=$img;
	}
	function setDescription($description)
	{
		 $this->description=$description;
	}	

	
}
?>