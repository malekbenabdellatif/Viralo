<?PHP
class Question{
	
	private $question;
	private $reponse;
	function __construct($question,$reponse)
	{
		
		$this->question=$question;
		$this->reponse=$reponse;
	}
	
	function getQuestion(){
		return $this->question;
	}
	
	function getReponse(){
		return $this->reponse;
	}
	

	

	function setQuestion($question){
		 $this->question=$question;
	}
		function setReponse($reponse){
		 $this->reponse=$reponse;
	}
	
}
?>