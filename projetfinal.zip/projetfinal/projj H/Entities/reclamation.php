<?PHP
class Reclamation{
	
	private $mail;
	private $sujet;
	private $textreclamation;
	function __construct($mail,$sujet,$textreclamation)
	{
		
		$this->mail=$mail;
		$this->sujet=$sujet;
		$this->textreclamation=$textreclamation;
	}
	
	function getMail(){
		return $this->mail;
	}
	
	function getSujet(){
		return $this->sujet;
	}
	function getTextreclamation(){
		return $this->textreclamation;
	}
	

	

	function setMail($mail){
		 $this->mail=$mail;
	}
		function setSujet($sujet){
		 $this->sujet=$sujet;
	}
	function setTextreclamation($textreclamation){
		 $this->textreclamation=$textreclamation;
	}
	
}
?>