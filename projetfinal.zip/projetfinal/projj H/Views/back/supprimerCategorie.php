<?PHP
include "../../core/categorieC.php";
//include "../../config.php";
$categorieC=new CategorieC();
if (isset($_POST["nom"])){
	$categorieC->supprimerCategorie($_POST["nom"]);
	header('Location: AfficherCategorie.php');
}

?>