<?PHP
include "../core/ReclamationC.php";
$reclamation1C=new ReclamationC();
$listeReclamation=$reclamation1C->afficherReclamation2();

?>
<table border="1">
    <tr>
        <td>idreclamation</td>
         <td>mail</td>
         <td>sujet</td>
        <td>textreclamation</td>
         
    </tr>

    <?PHP
    foreach($listeReclamation as $row){
        ?>
        <tr>
            <td><?PHP echo $row['idreclamation']; ?></td>
            <td><?PHP echo $row['mail']; ?></td>
             <td><?PHP echo $row['sujet']; ?></td>
            <td><?PHP echo $row['textreclamation']; ?></td>
           
          
            
            
        </tr>
        <?PHP
    }
    ?>
</table>
