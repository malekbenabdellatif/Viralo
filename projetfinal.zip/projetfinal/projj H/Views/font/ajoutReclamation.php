
<?PHP
include "../../config.php";
include "../../Entities/reclamation.php";
include "../../Core/ReclamationC.php";

if ( isset($_POST['mail']) and isset($_POST['sujet']) and isset($_POST['textreclamation']))  {

	
	
$reclamation1=new Reclamation($_POST['mail'],$_POST['sujet'],$_POST['textreclamation']);




$reclamation1C=new ReclamationC();
$reclamation1C->ajouterReclamation($reclamation1);
 /*header('Location: AfficherReclamation.php');*/
echo "votre reclamation est bien envoyer";
		
}
else
{
	echo "vérifier les champs";
}
//*/

?>