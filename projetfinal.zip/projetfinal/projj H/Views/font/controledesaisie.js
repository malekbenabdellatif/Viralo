function alpha(ch)
{
	ch = ch.toUpperCase();
	for (i=0;i<ch.length;i++)
	{
		c = ch.charAt(i);
		if (c < 'A' || c > 'Z')
			return false;
	}

	return true;
}
function verif()
{   ch1='produit';
	ch2='livraison';
    sujet1=f.sujet.value;
    result=sujet1.localeCompare(ch1);
    resultat=sujet1.localeCompare(ch2);
    if (result!=0 && resultat!=0)
    {
    	alert ("le champ sujet doit etre livraison ou produit");
    	return false;
    }
	text=f.textreclamation.value;
	if(alpha(text)==false || text.length<3 || text.length>30)
	{
		alert("champ textreclamation invalide");
		return false;
	} 
	

}