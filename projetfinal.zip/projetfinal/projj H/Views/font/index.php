<?php
include "../../Core/categorieC.php";
$categorie = new CategorieC();
$tab=$categorie->afficherCategories();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Archs &mdash; Onepage Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,700,900"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    
        <link rel="stylesheet" type="text/css" href="css/Panier.css">
  <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    

    <link rel="stylesheet" href="css/style.css">
    <script language="javascript"  src="controledesaisie.js"></script>
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div id="overlayer"></div>
  <div class="loader">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only">Loading...</span>
    </div>
  </div>

  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
    <div class="site-navbar-wrap">
      <div class="site-navbar-top">
        <div class="container py-3">
          <div class="row align-items-center">
            <div class="col-6">
              <a href="#" class="p-2 pl-0"><span class="icon-twitter"></span></a>
              <a href="#" class="p-2 pl-0"><span class="icon-facebook"></span></a>
              <a href="#" class="p-2 pl-0"><span class="icon-linkedin"></span></a>
              <a href="#" class="p-2 pl-0"><span class="icon-instagram"></span></a>
            </div>
            <div class="col-6">
              <div class="d-flex ml-auto">
                <a href="#" class="d-flex align-items-center ml-auto mr-4">
                  <span class="icon-envelope mr-2"></span>
                  <span class="d-none d-md-inline-block">deco-pierre@gmail.com</span>
                </a>
                <a href="#" class="d-flex align-items-center">
                  <span class="icon-phone mr-2"></span>
                  <span class="d-none d-md-inline-block">+21629403488</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="site-navbar site-navbar-target js-sticky-header">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-2">
              <h1 class="my-0 site-logo"><a href="index.html">Deco Pierre</a></h1>
            </div>
            <div class="col-10">
              <nav class="site-navigation text-right" role="navigation">
                <div class="container">
                  <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

                  <ul class="site-menu main-menu js-clone-nav d-none d-lg-block">
                    <li>
                      <a href="#home-section" class="nav-link">Home</a>
                    </li>
                    <li class="has-children">
                      <a href="#about-section" class="nav-link">À propos de nous</a>
                      <ul class="dropdown arrow-top">
                        <li><a href="#our-team-section" class="nav-link">Partenaire</a></li>
                        <li><a href="#faq-section" class="nav-link">FAQ</a></li>

                        </li>
                      </ul>
                    </li>
                    <li><a  href="#pricing-section" class="nav-link">Show Roms</a></li>
                    <li>
                      <a href="#our-team-sections" class="nav-link">Catégories</a>
                    </li>
                    <li><a href="#contact-section" class="nav-link">Réclamation</a></li>
                                        <li><a  href="connexion.html" class="nav-link">Compte</a></li>
<li>
  <a href="#">
  <div class="cadre">
<i class="fas fa-cart-arrow-down"></i>
<span class="num">0</span>    
  </div>
  </a>
</li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="site-blocks-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5"id="home-section">
      <div class="container">
        <div class="row align-items-center text-center justify-content-center">
          <div class="col-md-8">
            <a data-fancybox data-ratio="2" href="https://vimeo.com/317571768" class="play-button d-block">
              <span class="icon-play"></span>
            </a>
            <h1 class="text-uppercase">REINVENTEZ VOTRE VIE</h1>
            <span class="sub-text mb-3 d-block"><em>Des pierres du monde entier juste pour le plaisir de vos yeux</em></span>
          </div>
        </div>
      </div>
    </div>  

    
    <div class="site-section  border-bottom">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 mb-5 mb-lg-0">
            <div class="media custom-media">
              <div class="mr-3 icon"><span class="flaticon-turned-off display-4"></span></div>
              <div class="media-body">
                <h5 class="mt-0">CREATIVE</h5>
                Produits variés et créatifs spécialement conçus pour l'ambiance que vous choisissez..
              </div>
            </div>
          </div>


          <div class="col-lg-4 col-md-6 mb-5 mb-lg-0">
            <div class="media custom-media">
              <div class="mr-3 icon"><span class="flaticon-interior-design display-4"></span></div>
              <div class="media-body">
                <h5 class="mt-0">MODERNE</h5>
                Nos produits ne manquent pas de modernité car c'est l'une des qualités pour lesquelles les pierres sont connues..
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-5 mb-lg-0">
            <div class="media custom-media">
              <div class="mr-3 icon"><span class="flaticon-step-ladder display-4"></span></div>
              <div class="media-body">
                <h5 class="mt-0">CHALEUREUX</h5>
                Réchauffez votre maison en hiver car les pierres gardent la chaleur..
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>



    <div class="site-section about-section" id="about-section">
      <div class="container">
        <div class="row align-items-center mb-5 pb-5">
          <div class="col-lg-7 img-years mb-5 mb-lg-0">
            <img src="images/hero_bg_1.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto">
            <span class="sub-title">Deco Pierre</span>
            <h3 class="mb-4">À propos de nous</h3>
            <p class="mb-4">Nous sommes un groupe de personnes très créatif et très expérimenté en matière de conception de murs, nous avons des produits incroyables qui conviendraient à toute ambiance que vous souhaitez pour vos murs.</p>
            <ul class="list-unstyled ul-check text-left success mb-5">
                <li>CREATIVITE</li>
                <li>MODERNITE</li>
                <li>CHALEUR</li>
              </ul>
            <p><a href="#" class="btn btn-primary btn-lg rounded-0">En savoir plus sur nous</a></p>
          </div>
        </div>

        
      </div>
    </div>
    
    
    <div class="site-section" id="our-team-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <span class="sub-title">Nos Partenaires</span>
            <h2 class="font-weight-bold text-black">Partenaires</h2>
            <p class="mb-5">Ce sont les partenaires avec lesquels nous traitons et ensemble, nous nous assurons que notre client est parfaitement satisfait.</p>
          </div>
        </div>
       
        <div class="row">

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="person">
              <div class="bio-img">
                <figure>
                  <img src="images/ch.png" alt="Image" class="img-fluid">
                </figure>
                <div class="social">
                  <a href="#"><span class="icon-facebook"></span></a>
                  <a href="#"><span class="icon-twitter"></span></a>
                  <a href="#"><span class="icon-instagram"></span></a>
                </div>
              </div>
              <h2>Comptoires Hammami</h2>
              <span class="sub-title d-block mb-3">Matériaux</span>
              
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="person">
              <div class="bio-img">
                <figure>
                  <img src="images/p.jpg" alt="Image" class="img-fluid">
                </figure>
                <div class="social">
                  <a href="#"><span class="icon-facebook"></span></a>
                  <a href="#"><span class="icon-twitter"></span></a>
                  <a href="#"><span class="icon-instagram"></span></a>
                </div>
              </div>
              <h2>Perla Group</h2>
              <span class="sub-title d-block mb-3">Isolation</span>
            
              
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="person">
              <div class="bio-img">
                <figure>
                  <img src="images/m.png" alt="Image" class="img-fluid">
                </figure>
                <div class="social">
                  <a href="#"><span class="icon-facebook"></span></a>
                  <a href="#"><span class="icon-twitter"></span></a>
                  <a href="#"><span class="icon-instagram"></span></a>
                </div>
              </div>
              <h2>Mathios</h2>
              <span class="sub-title d-block mb-3">Matériaux réfractaires</span>
             
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="person">
              <div class="bio-img">
                <figure>
                  <img src="images/e.png" alt="Image" class="img-fluid">
                </figure>
                <div class="social">
                  <a href="#"><span class="icon-facebook"></span></a>
                  <a href="#"><span class="icon-twitter"></span></a>
                  <a href="#"><span class="icon-instagram"></span></a>
                </div>
              </div>
              <h2>El Kateb Group</h2>
              <span class="sub-title d-block mb-3">Investissements</span>
              
            </div>
          </div>

        

        </div>
      </div>
    </div>

    <div class="site-section" id="pricing-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <span class="sub-title">Notre show-room principale</span>
            <h2 class="font-weight-bold text-black">Show-room</h2>
          
          </div>
        </div>

    <div class="site-section about-section" id="about-section">
      <div class="container">
        <div class="row align-items-center mb-5 pb-5">
          <div class="col-lg-7 img-years mb-5 mb-lg-0">
            <img src="images/sr.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-lg-4 ml-auto">
            <p class="mb-4">Notre show-room est comme le paradis des pierres, vous pouvez trouver tout type de pierres avec n'importe quelle couleur de n'importe quel continent que vous aimez , tout ce que vous avez à faire est de choisir parmi nos centaines de choix.</p>
            <ul class="list-unstyled ul-check text-left success mb-5">
                <li>KM7 Route de Bizerte El Mnihla</li>

              </ul>
            <p><a href="#" class="btn btn-primary btn-lg rounded-0">Localisation</a></p>
          </div>
        </div>

        
      </div>
    </div>


        </div>
      </div>
    </div>   


    

    <div class="site-section" id="faq-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <img src="images/about_2.jpg" alt="Image" class="img-fluid">
          </div>
          
          <div class="col-lg-6 ml-auto pl-lg-5">
            <span class="sub-title">Demandez-nous, nous sommes heureux de répondre</span>
            <h2 class="font-weight-bold text-black mb-5">Questions les plus répétées</h2>
            <div class="accordion" id="accordionExample">
              

              <div class="accordion-item">
                <h2 class="mb-0 rounded mb-2">
                  <a href="#" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Ces pierres sont-elles de vraies pierres?</a>
                </h2>

                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="accordion-body">
                    <p>Oui, nos pierres sont en fait réelles, apportées de différentes montagnes du monde comme la Turquie, la Chine, l'Islande etc...</p>
                  </div>
                </div>
              </div>
              
              <div class="accordion-item">
                <h2 class="mb-0 rounded mb-2">
                  <a href="#" class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Quel est votre processus?
                  </a>
                </h2>
               
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                  <div class="accordion-body">
                    <p>Nous coupons les pierres importées de l'extérieur des pays et nous les ajoutons à notre catalogue à partir duquel le client choisit le modèle qu'il aime, et après plus d'informations, nous fournissons les pierres avec des travailleurs pour les mettre sur vos murs afin que le client puisse simplement se reposer et regarder.</p>
                  </div>
                </div>
              </div>
              
              <div class="accordion-item">
                <h2 class="mb-0 rounded mb-2">
                  <a href="#" class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Combien coûte le processus?
                  </a>
                </h2>
                
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                  <div class="accordion-body">
                    <p>Les prix varient d'un modèle à l'autre, vous pouvez visiter la page des produits pour vérifier les prix.</p>
                  </div>
                </div>
              </div>
              
              <div class="accordion-item">
                <h2 class="mb-0 rounded mb-2">
                  <a href="#" class="collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                    Où vous trouver? Où est votre emplacement?
                  </a>
                </h2>

                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                  <div class="accordion-body">
                    <p>L'adress de notre show-room principale est Km7 route de bizerte El Mnihla.</p>
                  </div>
                </div>
              </div>

             
            </div>

          </div>
        </div>
      </div>
    </div>

    
    <div class="container site-section block-13 testimonial-wrap">

      <div class="row">
        <div class="col-12 text-center">
          <span class="sub-title">CLIENTS SATISFAITS</span>
          <h2 class="font-weight-bold text-black mb-5">Testimonials</h2>
        </div>
      </div>

      <div class="nonloop-block-13 owl-carousel">
        
        <div class="testimony px-5">
          <img src="images/person_1.jpg" alt="Image" class="img-fluid">
          <h3>Maha Ben Samir</h3>
          <span class="sub-title">Journaliste.</span>
          <p>&ldquo;<em>Je suis très satisfait du produit, la qualité des pierres est parfaite et maintenant je peux profiter de ma cheminée dans les hivers froids.</em>&rdquo;</p>
        </div>
      
        <div class="testimony px-5">
          <img src="images/person_2.jpg" alt="Image" class="img-fluid">
          <h3>Mohamed Ben Ali</h3>
          <span class="sub-title">Directeur Exécutif.</span>
          <p>&ldquo;<em>Les pierres sont très belles et agréables à regarder, je recommande fortement de les ajouter à vos murs, que ce soit à l'intérieur de la maison pour que vous puissiez en profiter ou à l'extérieur de la maison pour que tout le monde puisse les voir.</em>&rdquo;</p>
        </div>

        <div class="testimony px-5">
          <img src="images/person_3.jpg" alt="Image" class="img-fluid">
          <h3>Louay Belhaj</h3>
          <span class="sub-title">Ingenieur.</span>
          <p>&ldquo;<em>Un choix très variant et creatif , j'ai choisi les pierres jaunes pour correspondre à mes murs blancs et je vous le dis, c'est sorti incroyable et maintenant je ne peux plus arrêter de les regarder.</em>&rdquo;</p>
        </div>

        <div class="testimony px-5">
          <img src="images/person_4.jpg" alt="Image" class="img-fluid">
          <h3>Ali Sallemi</h3>
          <span class="sub-title">Décorateur d'intérieur.</span>
          <p>&ldquo;<em>La beauté de ma maison est maintenant insaisissable, tout le monde me complimente et en tant qu'architecte d'intérieur, je peux approuver l'élégance de ces pierres.</em>&rdquo;</p>
        </div>
      </div>
    </div>

    
    <div class="site-section" id="our-team-sections">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <span class="sub-title">Nos Catégories</span>
            <h2 class="font-weight-bold text-black">Catégories</h2>
            <p class="mb-5">Ce sont les partenaires avec lesquels nous traitons et ensemble, nous nous assurons que notre client est parfaitement satisfait.</p>
          </div>
        </div>
       
        <div class="row">
<?php 
foreach ($tab as $row) {

?>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="person">
              <div class="bio-img">
                <figure>
                  <?php
          echo' <img src="data:image/jpeg;base64,'.base64_encode($row['img']).'" alt="" class="img-fluid" />';
          ?>
                </figure>
                <div class="social">
                  <a  href="produit.php"> choisissez </a>
                </div>
              </div>
              <h2><?php echo $row['nom']; ?></h2>
              
            </div>
          </div>

<?php }  ?>      

        </div>
      </div>
    </div>

    

    <div class="site-section bg-light" id="contact-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <span class="sub-title">Réclamation</span>
            <h2 class="font-weight-bold text-black">Contactez Nous</h2>
            <p class="mb-5">Contactez-nous et demandez ou réclamez tout ce que vous voulez savoir et nous vous répondrons dans les plus brefs délais.</p>
          </div>
        </div>
        <div class="row">
          
          <div class="col-md-12 col-lg-12">
             <form method="POST" action="ajoutReclamation.php" name="f">
            

              
              <div class="row form-group">
                <div class="col-md-12">
                  <label class="font-weight-bold" for="email">Email</label>
                  <input type="email" id="mail"  name="mail"class="form-control" placeholder="mail">
                </div>
              </div>
                 <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="font-weight-bold" for="sujet">sujet</label>
                  <input type="text" id="sujet" name="sujet"class="form-control" placeholder="sujet:livraison ou produit">
                </div>
              </div>
             <div class="row form-group">
                <div class="col-md-12">
                  <label class="font-weight-bold" for="textreclamation">Message</label> 
                  <textarea name="textreclamation" id="textreclamation" cols="30" rows="5" class="form-control" placeholder="Bonjour"></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" name="ajouter"value="ajouter" id="ajouter"class="btn btn-primary rounded-0 btn-lg" onclick="return verif()">
                  
                </div>
              </div>

  
            </form>
          </div>
        </div>
      </div>
    </div>

    <footer class="site-footer border-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 mb-5 mb-lg-0">
            <div class="row mb-5">
              <div class="col-12">
            </div>
          

           
            <div align="text-center">
                <h3 class="footer-heading mb-4">Suivez-nous</h3>
                <div>
                  <a href="#" class="pl-0 pr-3"><span class="icon-facebook"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
                  <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
                </div>
              </div>
            </div>
            </div>


        
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.sticky.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/main.js"></script>
  
  
  </body>
</html>